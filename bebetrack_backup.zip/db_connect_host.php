<?php
    $servername = "localhost";
    $username = "id18662737_id18536261_trackbbs";
    $password = "@4kw9c@p{Pcww9V9";
    $dbname = "id18662737_bbstracking";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);

    // Change character set to utf8
    $conn->set_charset("utf8");
    };
?>